Instructions for Setting Up PS2 on IntelliJ
-------------------------------------------
Extract the entire 'ps2' directory in the zip file to a directory of your choice on your computer.
Then, go to IntelliJ and click File > Open. Select the 'ps2' directory that you have extracted and click 'Ok'.

Common Errors
1. java: error: release version 15 not supported
  - Go to File > Project Structure > Project
  - Set Language Level to 11

